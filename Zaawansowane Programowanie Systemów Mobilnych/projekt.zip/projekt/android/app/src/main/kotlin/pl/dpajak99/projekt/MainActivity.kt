package pl.dpajak99.projekt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
