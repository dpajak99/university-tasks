class RegisterResponse {
  final String userId;

  RegisterResponse({required this.userId});
}