import 'package:flutter/cupertino.dart';

class NoGlowBehaviour extends ScrollBehavior {}
