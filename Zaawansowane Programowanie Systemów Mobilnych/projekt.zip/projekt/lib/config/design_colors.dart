import 'package:flutter/material.dart';

class DesignColors {
  static const Color white = Color(0xFFFFFFFF);
  static const Color blue = Color(0xFF27AAFF);
}