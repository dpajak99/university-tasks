package com.tarbus.payload.entity.mongo.message;

public enum MessageStatus {
  delivered, error, seen, sending, sent
}
