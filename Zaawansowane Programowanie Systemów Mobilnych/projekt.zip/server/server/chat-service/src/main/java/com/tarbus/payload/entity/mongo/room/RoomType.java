package com.tarbus.payload.entity.mongo.room;

public enum RoomType {
  channel, group
}
