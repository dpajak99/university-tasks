package com.tarbus.payload.entity.mongo.message;

public enum MessageType {
  custom,
  file,
  image,
  text,
  unsupported,
}
