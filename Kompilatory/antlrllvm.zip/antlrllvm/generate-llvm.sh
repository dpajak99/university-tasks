clang -emit-llvm -S ./samples/example.cc -o outputs/hello.ll
