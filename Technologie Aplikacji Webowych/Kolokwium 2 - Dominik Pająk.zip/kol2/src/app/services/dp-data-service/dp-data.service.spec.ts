import { TestBed } from '@angular/core/testing';

import { DpDataService } from './dp-data.service';

describe('DpDataService', () => {
  let service: DpDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DpDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
