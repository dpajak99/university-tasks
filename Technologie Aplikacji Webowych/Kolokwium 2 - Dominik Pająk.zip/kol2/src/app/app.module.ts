import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrdersDpComponent } from './components/orders-dp/orders-dp.component';
import { OrdersItemDpComponent } from './components/orders-item-dp/orders-item-dp.component';
import { OrdersDetailsDpComponent } from './components/orders-details-dp/orders-details-dp.component';
import {HttpClientModule} from "@angular/common/http";
import {DpDataService} from "./services/dp-data-service/dp-data.service";

@NgModule({
  declarations: [
    AppComponent,
    OrdersDpComponent,
    OrdersItemDpComponent,
    OrdersDetailsDpComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    DpDataService
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
