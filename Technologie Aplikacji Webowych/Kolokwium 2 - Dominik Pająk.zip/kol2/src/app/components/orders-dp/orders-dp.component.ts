import {Component, OnInit} from '@angular/core';
import {DpDataService} from "../../services/dp-data-service/dp-data.service";

@Component({
  selector: 'app-orders-dp',
  templateUrl: './orders-dp.component.html',
  styleUrls: ['./orders-dp.component.css']
})
export class OrdersDpComponent implements OnInit {
  public items$: any;

  constructor(private service: DpDataService) {
  }

  ngOnInit(): void {
    this.getAll();
  }

  getAll() {
    this.service.getAll().subscribe(response => {
      this.items$ = response;
    })
  }
}
