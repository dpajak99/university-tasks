import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersDpComponent } from './orders-dp.component';

describe('OrdersDpComponent', () => {
  let component: OrdersDpComponent;
  let fixture: ComponentFixture<OrdersDpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersDpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersDpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
