import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-orders-item-dp',
  templateUrl: './orders-item-dp.component.html',
  styleUrls: ['./orders-item-dp.component.css']
})
export class OrdersItemDpComponent implements OnInit {

  @Input() item: any;

  constructor() { }

  ngOnInit(): void {
  }

}
