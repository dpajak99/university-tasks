import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersItemDpComponent } from './orders-item-dp.component';

describe('OrdersItemDpComponent', () => {
  let component: OrdersItemDpComponent;
  let fixture: ComponentFixture<OrdersItemDpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersItemDpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersItemDpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
