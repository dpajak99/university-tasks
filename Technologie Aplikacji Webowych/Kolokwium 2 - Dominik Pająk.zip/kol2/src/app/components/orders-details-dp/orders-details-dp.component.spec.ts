import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersDetailsDpComponent } from './orders-details-dp.component';

describe('OrdersDetailsDpComponent', () => {
  let component: OrdersDetailsDpComponent;
  let fixture: ComponentFixture<OrdersDetailsDpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersDetailsDpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersDetailsDpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
