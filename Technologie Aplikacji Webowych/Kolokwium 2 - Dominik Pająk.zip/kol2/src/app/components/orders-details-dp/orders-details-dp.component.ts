import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {DpDataService} from "../../services/dp-data-service/dp-data.service";

@Component({
  selector: 'app-orders-details-dp',
  templateUrl: './orders-details-dp.component.html',
  styleUrls: ['./orders-details-dp.component.css']
})
export class OrdersDetailsDpComponent implements OnInit {

  public item$: any;

  constructor(private service: DpDataService, private route: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.getById();
  }

  getById() {
    let id: string = '';

    this.route.paramMap.subscribe((params: any) => {
      id = params.get('id');
    })

    this.service.getById(id).subscribe((res: any) => {
      this.item$ = res;
    });
  }

}
