import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {OrdersDpComponent} from "./components/orders-dp/orders-dp.component";
import {OrdersDetailsDpComponent} from "./components/orders-details-dp/orders-details-dp.component";
import {OrdersItemDpComponent} from "./components/orders-item-dp/orders-item-dp.component";

const routes: Routes = [
  {
    path: '',
    component: OrdersDpComponent
  },
  {
    path: 'api/posts/:id',
    component: OrdersDetailsDpComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
